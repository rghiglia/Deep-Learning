# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 12:12:37 2017

@author: rghiglia
"""

import sys
import numpy as np
import pandas as pd
#import matplotlib.pyplot as plt


sys.path.append(r'C:\Users\rghiglia\Documents\ML_ND\Toolbox')

dnm = r'C:\Users\rghiglia\Documents\ML_ND\Reviewer_projects\DeepLearning_20170130\DLND-your-first-network\Bike-Sharing-Dataset'
fnm = r'hour.csv'
fnmL = dnm + '//' + fnm

rides   = pd.read_csv(fnmL)
rides.head()
# This dataset has the number of riders for each hour of each day from January 1 2011 to December 31 2012. The number of riders is split between casual and registered, summed up in the cnt column. You can see the first few rows of the data above.

data_tmp = rides
print "Training dataset has {} samples with {} features.".format(*data_tmp.shape)
data_tmp.info()
data_tmp.head()
data_tmp.describe()

rides[:24*10].plot(x='dteday', y='cnt')

dummy_fields = ['season', 'weathersit', 'mnth', 'hr', 'weekday']
for fld in dummy_fields:
    dummies = pd.get_dummies(rides[fld], prefix=fld, drop_first=False)
    rides = pd.concat([rides, dummies], axis=1)

fields_to_drop = ['instant', 'dteday', 'season', 'weathersit', 
                  'weekday', 'atemp', 'mnth', 'workingday', 'hr']
data = rides.drop(fields_to_drop, axis=1)
data.head()


quant_features = ['casual', 'registered', 'cnt', 'temp', 'hum', 'windspeed']
# Store scalings in a dictionary so we can convert back later
scaled_features = {}
for col in quant_features:
    mean, std = data[col].mean(), data[col].std()
    scaled_features[col] = [mean, std]
    data.loc[:, col] = (data[col] - mean)/std


# Save the last 21 days 
test_data = data[-21*24:]
data = data[:-21*24]

# Separate the data into features and targets
target_fields = ['cnt', 'casual', 'registered']
features, targets = data.drop(target_fields, axis=1), data[target_fields]
test_features, test_targets = test_data.drop(target_fields, axis=1), test_data[target_fields]


# Hold out the last 60 days of the remaining data as a validation set
train_features, train_targets = features[:-60*24], targets[:-60*24]
val_features, val_targets = features[-60*24:], targets[-60*24:]

print train_features.shape


import math

def activation(x,typ='sigmoid'):
    nR, nC = x.shape
    y = np.zeros_like(x)
    for iC in range(0,nC-1):
        if typ=='lin':
            y[:,iC] = [xi for xi in x[:,iC]]
        elif typ=='sigmoid':
            y[:,iC] = [1.0/(1.0+math.exp(-xi)) for xi in x[:,iC]]
    return y


class NeuralNetwork(object):
    def __init__(self, input_nodes, hidden_nodes, output_nodes, learning_rate):
        # Set number of nodes in input, hidden and output layers.
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
#        print
#        print self.input_nodes
#        print self.hidden_nodes
#        print self.output_nodes

        # Initialize weights
        self.weights_input_to_hidden = np.random.normal(0.0, self.hidden_nodes**-0.5, 
                                       (self.hidden_nodes, self.input_nodes))

        self.weights_hidden_to_output = np.random.normal(0.0, self.output_nodes**-0.5, 
                                       (self.output_nodes, self.hidden_nodes))
        self.lr = learning_rate
#        print
#        print self.weights_input_to_hidden.shape
#        print self.weights_hidden_to_output.shape
#        print self.lr
        # Weight matrices are n_output x n_input
        
        #### Set this to your implemented sigmoid function ####
        # Activation function is the sigmoid function
        self.activation_function = activation
    
    def train(self, inputs_list, targets_list):
        # Convert inputs list to 2d array
        inputs = np.array(inputs_list, ndmin=2).T
        targets = np.array(targets_list, ndmin=2).T

        #### Implement the forward pass here ####
        ### Forward pass ###
        # TODO: Hidden layer
        hidden_inputs = inputs
        hidden_outputs = weights_input_to_hidden*hidden_inputs
        
        # TODO: Output layer
        final_inputs = hidden_outputs
        final_outputs = self.activation_function(weights_hidden_to_output*final_inputs)
        
        #### Implement the backward pass here ####
        ### Backward pass ###
        
        # TODO: Output error
        output_errors = targets - final_outputs
        
        # TODO: Backpropagated error
        hidden_errors = 0 # errors propagated to the hidden layer
        hidden_grad = hidden_errors
        
        # TODO: Update the weights
        self.weights_hidden_to_output += -self.lr * hidden_grad # update hidden-to-output weights with gradient descent step
        self.weights_input_to_hidden += 0 # update input-to-hidden weights with gradient descent step
 
        
    def run(self, inputs_list):
        # Run a forward pass through the network
        inputs = np.array(inputs_list, ndmin=2).T
        
        print inputs.shape
        
        #### Implement the forward pass here ####
        # TODO: Hidden layer
        hidden_inputs = np.dot(self.weights_input_to_hidden,inputs)             # signals into hidden layer
        hidden_outputs = self.activation_function(hidden_inputs,'lin')          # signals from hidden layer

        # TODO: Output layer
        final_inputs = np.dot(self.weights_hidden_to_output,hidden_outputs)     # signals into final output layer
        final_outputs = self.activation_function(final_inputs,'sigmoid')        # signals from final output layer 
        
        return final_outputs



nObs, nI = train_features.shape
_, nO = train_targets.shape

nn = NeuralNetwork(nI,10,nO,0.1)

nn.run(train_features)
# Ok, so it just transposes them

