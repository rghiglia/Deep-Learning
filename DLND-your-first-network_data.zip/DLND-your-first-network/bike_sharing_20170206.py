# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 12:12:37 2017

@author: rghiglia
"""

import sys
import numpy as np
import pandas as pd
#import matplotlib.pyplot as plt


sys.path.append(r'C:\Users\rghiglia\Documents\ML_ND\Toolbox')

dnm = r'C:\Users\rghiglia\Documents\ML_ND\Reviewer_projects\DeepLearning_20170130\DLND-your-first-network\Bike-Sharing-Dataset'
fnm = r'hour.csv'
fnmL = dnm + '//' + fnm

rides   = pd.read_csv(fnmL)
rides.head()
# This dataset has the number of riders for each hour of each day from January 1 2011 to December 31 2012. The number of riders is split between casual and registered, summed up in the cnt column. You can see the first few rows of the data above.

data_tmp = rides
print "Training dataset has {} samples with {} features.".format(*data_tmp.shape)
data_tmp.info()
data_tmp.head()
data_tmp.describe()

rides[:24*10].plot(x='dteday', y='cnt')

dummy_fields = ['season', 'weathersit', 'mnth', 'hr', 'weekday']
for fld in dummy_fields:
    dummies = pd.get_dummies(rides[fld], prefix=fld, drop_first=False)
    rides = pd.concat([rides, dummies], axis=1)

fields_to_drop = ['instant', 'dteday', 'season', 'weathersit', 
                  'weekday', 'atemp', 'mnth', 'workingday', 'hr']
data = rides.drop(fields_to_drop, axis=1)
data.head()


quant_features = ['casual', 'registered', 'cnt', 'temp', 'hum', 'windspeed']
# Store scalings in a dictionary so we can convert back later
scaled_features = {}
for col in quant_features:
    mean, std = data[col].mean(), data[col].std()
    scaled_features[col] = [mean, std]
    data.loc[:, col] = (data[col] - mean)/std


# Save the last 21 days 
test_data = data[-21*24:]
data = data[:-21*24]

# Separate the data into features and targets
target_fields = ['cnt', 'casual', 'registered']
features, targets = data.drop(target_fields, axis=1), data[target_fields]
test_features, test_targets = test_data.drop(target_fields, axis=1), test_data[target_fields]


# Hold out the last 60 days of the remaining data as a validation set
train_features, train_targets = features[:-60*24], targets[:-60*24]
val_features, val_targets = features[-60*24:], targets[-60*24:]

print train_features.shape



def activation(x,typ='sigmoid'):
    if np.isscalar(x):
        x_tmp = np.zeros([1,1])
        x_tmp[0] = x
        x = x_tmp
    nR, nC = x.shape
    y = np.zeros_like(x)
    for iC in range(0,nC):
        if typ=='lin':
            y[:,iC] = [xi for xi in x[:,iC]]
        elif typ=='sigmoid':
            y[:,iC] = [1.0/(1.0+np.exp(-xi)) for xi in x[:,iC]]
    y = np.array(y, ndmin=2)
    return y
y = activation(0.5)
print y.shape

class NeuralNetwork(object):
    def __init__(self, input_nodes, hidden_nodes, output_nodes, learning_rate):
        # Set number of nodes in input, hidden and output layers.
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
#        print
#        print self.input_nodes
#        print self.hidden_nodes
#        print self.output_nodes

        # Initialize weights
        self.weights_input_to_hidden = np.random.normal(0.0, self.hidden_nodes**-0.5, 
                                       (self.hidden_nodes, self.input_nodes))

        self.weights_hidden_to_output = np.random.normal(0.0, self.output_nodes**-0.5, 
                                       (self.output_nodes, self.hidden_nodes))
        self.lr = learning_rate
#        print
#        print self.weights_input_to_hidden.shape
#        print self.weights_hidden_to_output.shape
#        print self.lr
        # Weight matrices are n_output x n_input
        
        #### Set this to your implemented sigmoid function ####
        # Activation function is the sigmoid function
        self.activation_function = activation
    
    def train(self, inputs_list, targets_list):
        # Convert inputs list to 2d array
        inputs = np.array(inputs_list, ndmin=2).T
        targets = np.array(targets_list, ndmin=2).T

        #### Implement the forward pass here ####
        ### Forward pass ###
        # TODO: Hidden layer
        print 'Inputs ', inputs.shape
        print 'W_ih ', self.weights_input_to_hidden.shape
        print 'W_ho ', self.weights_hidden_to_output.shape
        hidden_inputs = self.activation_function(inputs)
        print 'H Inputs ', hidden_inputs.shape
        hidden_outputs = np.dot(self.weights_input_to_hidden,hidden_inputs)
        print 'H Outputs ', hidden_outputs.shape
        print 'H Outputs Trans', hidden_outputs.T.shape
        
        # TODO: Output layer
        final_inputs = self.activation_function(hidden_outputs,'lin')
        final_outputs = np.dot(self.weights_hidden_to_output,final_inputs)
        print 'Final inputs ', final_inputs.shape
        print 'Final inputs transp', final_inputs.T.shape
        print 'Final outputs ', final_outputs.shape
        
        #### Implement the backward pass here ####
        ### Backward pass ###
        
        # TODO: Output error
        output_errors = targets - final_outputs
        
        # TODO: Backpropagated error
#        hidden_errors = 0 # errors propagated to the hidden layer
        nO = inputs.shape[1]
        print '# Obs', nO
        for iO in range(0,nO):
            print 'Outputs error', output_errors.shape
            print 'Final inputs Transp', np.array(final_inputs[:,iO],ndmin=2).T.shape
            hidden_grad = np.outer(output_errors,final_inputs[:,iO])
            print 'Hidden grad', hidden_grad.shape
            act_prime = self.activation_function(hidden_inputs)*(1-self.activation_function(hidden_inputs))
            Ia = np.diag(self.activation_function(inputs))
            print 'Ia', Ia.shape
            input_grad = np.dot(np.dot(Ia,self.weights_hidden_to_output),np.outer(act_prime,hidden_inputs[:,iO]))
            print 'Input grad', input_grad.shape
        
#        # TODO: Update the weights
#        self.weights_hidden_to_output += -self.lr * hidden_grad # update hidden-to-output weights with gradient descent step
#        self.weights_input_to_hidden += 0 # update input-to-hidden weights with gradient descent step
 
        
    def run(self, inputs_list):
        # Run a forward pass through the network
        inputs = np.array(inputs_list, ndmin=2).T
        
        print inputs.shape
        
        #### Implement the forward pass here ####
        # TODO: Hidden layer
        hidden_inputs = np.dot(self.weights_input_to_hidden,inputs)             # signals into hidden layer
        hidden_outputs = self.activation_function(hidden_inputs,'sigmoid')      # signals from hidden layer

        # TODO: Output layer
        final_inputs = np.dot(self.weights_hidden_to_output,hidden_outputs)     # signals into final output layer
        final_outputs = self.activation_function(final_inputs,'lin')            # signals from final output layer 
        
        return final_outputs



#nObs, nI = train_features.shape
#_, nO = train_targets.shape
#
#nn = NeuralNetwork(nI,10,nO,0.1)
#
#nn.run(train_features)
#nn.train(train_features, train_targets)
### Ok, so it just transposes them



#import unittest

inputs = [0.5, -0.2, 0.1]
targets = [0.4]
test_w_i_h = np.array([[0.1, 0.4, -0.3], 
                       [-0.2, 0.5, 0.2]])
test_w_h_o = np.array([[0.3, -0.1]])

network = NeuralNetwork(3, 2, 1, 0.5)

## Test that the activation function is a sigmoid
#np.all(network.activation_function(0.5,'sigmoid') == 1/(1+np.exp(-0.5)))

# Test training
network.weights_input_to_hidden = test_w_i_h.copy()
network.weights_hidden_to_output = test_w_h_o.copy()

network.train(inputs, targets)
network.run(inputs)




#class TestMethods(unittest.TestCase):
#    
#    ##########
#    # Unit tests for data loading
#    ##########
#    
#    def test_data_path(self):
#        # Test that file path to dataset has been unaltered
#        self.assertTrue(data_path.lower() == 'bike-sharing-dataset/hour.csv')
#        
#    def test_data_loaded(self):
#        # Test that data frame loaded
#        self.assertTrue(isinstance(rides, pd.DataFrame))
#    
#    ##########
#    # Unit tests for network functionality
#    ##########
#
#    def test_activation(self):
#        network = NeuralNetwork(3, 2, 1, 0.5)
#        # Test that the activation function is a sigmoid
#        self.assertTrue(np.all(network.activation_function(0.5) == 1/(1+np.exp(-0.5))))
#
#    def test_train(self):
#        # Test that weights are updated correctly on training
#        network = NeuralNetwork(3, 2, 1, 0.5)
#        network.weights_input_to_hidden = test_w_i_h.copy()
#        network.weights_hidden_to_output = test_w_h_o.copy()
#        
#        network.train(inputs, targets)
#        self.assertTrue(np.allclose(network.weights_hidden_to_output, 
#                                    np.array([[ 0.37275328, -0.03172939]])))
#        self.assertTrue(np.allclose(network.weights_input_to_hidden,
#                                    np.array([[ 0.10562014,  0.39775194, -0.29887597],
#                                              [-0.20185996,  0.50074398,  0.19962801]])))
#
#    def test_run(self):
#        # Test correctness of run method
#        network = NeuralNetwork(3, 2, 1, 0.5)
#        network.weights_input_to_hidden = test_w_i_h.copy()
#        network.weights_hidden_to_output = test_w_h_o.copy()
#
#        self.assertTrue(np.allclose(network.run(inputs), 0.09998924))
#
#suite = unittest.TestLoader().loadTestsFromModule(TestMethods())
#unittest.TextTestRunner().run(suite)



