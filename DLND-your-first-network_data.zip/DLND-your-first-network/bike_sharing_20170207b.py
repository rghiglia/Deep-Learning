# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 12:12:37 2017

@author: rghiglia
"""

import sys
import numpy as np
import pandas as pd
#import matplotlib.pyplot as plt


sys.path.append(r'C:\Users\rghiglia\Documents\ML_ND\Toolbox')

dnm = r'C:\Users\rghiglia\Documents\ML_ND\Reviewer_projects\DeepLearning_20170130\DLND-your-first-network\Bike-Sharing-Dataset'
fnm = r'hour.csv'
fnmL = dnm + '//' + fnm

rides   = pd.read_csv(fnmL)
rides.head()
# This dataset has the number of riders for each hour of each day from January 1 2011 to December 31 2012. The number of riders is split between casual and registered, summed up in the cnt column. You can see the first few rows of the data above.

data_tmp = rides
print "Training dataset has {} samples with {} features.".format(*data_tmp.shape)
data_tmp.info()
data_tmp.head()
data_tmp.describe()

rides[:24*10].plot(x='dteday', y='cnt')

dummy_fields = ['season', 'weathersit', 'mnth', 'hr', 'weekday']
for fld in dummy_fields:
    dummies = pd.get_dummies(rides[fld], prefix=fld, drop_first=False)
    rides = pd.concat([rides, dummies], axis=1)

fields_to_drop = ['instant', 'dteday', 'season', 'weathersit', 
                  'weekday', 'atemp', 'mnth', 'workingday', 'hr']
data = rides.drop(fields_to_drop, axis=1)
data.head()


quant_features = ['casual', 'registered', 'cnt', 'temp', 'hum', 'windspeed']
# Store scalings in a dictionary so we can convert back later
scaled_features = {}
for col in quant_features:
    mean, std = data[col].mean(), data[col].std()
    scaled_features[col] = [mean, std]
    data.loc[:, col] = (data[col] - mean)/std


# Save the last 21 days 
test_data = data[-21*24:]
data = data[:-21*24]

# Separate the data into features and targets
target_fields = ['cnt', 'casual', 'registered']
features, targets = data.drop(target_fields, axis=1), data[target_fields]
test_features, test_targets = test_data.drop(target_fields, axis=1), test_data[target_fields]


# Hold out the last 60 days of the remaining data as a validation set
train_features, train_targets = features[:-60*24], targets[:-60*24]
val_features, val_targets = features[-60*24:], targets[-60*24:]

print train_features.shape



def activation(x,typ='sigmoid'):
    x = np.array(x,ndmin=2)
    nR, nC = x.shape
    y = np.zeros_like(x)
    for iC in range(0,nC):
        if typ=='lin':
            y[:,iC] = [xi for xi in x[:,iC]]
        elif typ=='sigmoid':
            y[:,iC] = [1.0/(1.0+np.exp(-xi)) for xi in x[:,iC]]
    y = np.array(y, ndmin=2)
    return y
y = activation(0.5)
print y.shape
y = activation([0.5, 0.1])
print y.shape
y = activation(np.array([0.5, 0.1],ndmin=2).T)
print y.shape




class NeuralNetwork(object):
    def __init__(self, input_nodes, hidden_nodes, output_nodes, learning_rate):
        # Set number of nodes in input, hidden and output layers.
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes

        # Initialize weights
        self.weights_input_to_hidden = np.random.normal(0.0, self.hidden_nodes**-0.5, 
                                       (self.hidden_nodes, self.input_nodes))

        self.weights_hidden_to_output = np.random.normal(0.0, self.output_nodes**-0.5, 
                                       (self.output_nodes, self.hidden_nodes))
        self.lr = learning_rate
        # Weight matrices are n_output x n_input
        
        #### Set this to your implemented sigmoid function ####
        # Activation function is the sigmoid function
        self.activation_function = activation
    
    def train(self, inputs_list, targets_list):
        # Convert inputs list to 2d array
        inputs = np.array(inputs_list, ndmin=2).T
        targets = np.array(targets_list, ndmin=2).T
        # Inputs and outputs are (column-)stacked observations

        #### Implement the forward pass here ####
        ### Forward pass ###
        # TODO: Hidden layer
        hidden_inputs = np.dot(self.weights_input_to_hidden,inputs)
        hidden_outputs = self.activation_function(hidden_inputs,'sigmoid')
        
        # TODO: Output layer
        final_inputs = np.dot(self.weights_hidden_to_output,hidden_outputs)
        final_outputs = self.activation_function(final_inputs,'lin')
        
        
        #### Implement the backward pass here ####
        ### Backward pass ###
        
        # TODO: Output error
        output_errors = targets - final_outputs
        
        # TODO: Backpropagated error

        nO = inputs.shape[1]
        for iO in range(0,nO):
            print 'Obs ', iO+1, ' /', nO

            # Gradient of hidden_to_output
            grad_h_o = -np.outer(output_errors,hidden_outputs[:,iO])
            
            # Gradient of input_to_hidden
            h_inp   = np.array(hidden_inputs[:,iO], ndmin=2).T          # make sure it's a column vector
            inp     = np.array(inputs[:,iO], ndmin=2).T
            act_prime = self.activation_function(h_inp)*(1-self.activation_function(h_inp)) # derivative of a sigmoidal function, evaluated at hidden_inputs
            Ia_prime = np.diag(act_prime[:,0])                          # create a diagonal matrix
            Kappa = np.dot(self.weights_hidden_to_output,Ia_prime)
            grad_i_h = -np.outer(np.dot(output_errors.T,Kappa),inp)     # note: this should really be activation(inp) but assuming that the input layer has no activation, as reasonably so, because that could simply be done by converting the input dataset, so it becomes semantics, really
            # In matrix form:
            # de E / de W_{m-1,m} = [e^T . K]^T . y_{m-1}^T
            # K = I(a'_n) . W_{n-1,n} . I(a'_{n-1}) . ... . I(a'_{m}) 

            # TODO: Update the weights
            self.weights_hidden_to_output += -self.lr * grad_h_o # update hidden-to-output weights with gradient descent step
            self.weights_input_to_hidden += -self.lr * grad_i_h # update input-to-hidden weights with gradient descent step
 
        
    def run(self, inputs_list):
        # Run a forward pass through the network
        inputs = np.array(inputs_list, ndmin=2).T
        
        print inputs.shape
        
        #### Implement the forward pass here ####
        # TODO: Hidden layer
        hidden_inputs = np.dot(self.weights_input_to_hidden,inputs)             # signals into hidden layer
        hidden_outputs = self.activation_function(hidden_inputs,'sigmoid')      # signals from hidden layer

        # TODO: Output layer
        final_inputs = np.dot(self.weights_hidden_to_output,hidden_outputs)     # signals into final output layer
        final_outputs = self.activation_function(final_inputs,'lin')            # signals from final output layer 
        
        return final_outputs


# --------------------------------------------------
# Tests
# --------------------------------------------------

network = NeuralNetwork(3, 2, 1, 0.5)

# Test that the activation function is a sigmoid
np.all(network.activation_function(0.5,'sigmoid') == 1/(1+np.exp(-0.5)))


# Test training

# Inputs
inputs = [0.5, -0.2, 0.1]
targets = [0.4]
test_w_i_h = np.array([[0.1, 0.4, -0.3], 
                       [-0.2, 0.5, 0.2]])
test_w_h_o = np.array([[0.3, -0.1]])
network.weights_input_to_hidden = test_w_i_h.copy()
network.weights_hidden_to_output = test_w_h_o.copy()

# Run
network.run(inputs)
#        self.assertTrue(np.allclose(network.run(inputs), 0.09998924))


# Train
network.train(inputs, targets)
network.weights_input_to_hidden
#        self.assertTrue(np.allclose(network.weights_input_to_hidden,
#                                    np.array([[ 0.10562014,  0.39775194, -0.29887597],
#                                              [-0.20185996,  0.50074398,  0.19962801]])))
network.weights_hidden_to_output
#        self.assertTrue(np.allclose(network.weights_hidden_to_output, 
#                                    np.array([[ 0.37275328, -0.03172939]])))





